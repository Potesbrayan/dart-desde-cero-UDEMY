# Notas

Ejercicios básicos de mi curso de Dart

[Dart: De cero hasta los detalles](https://fernando-herrera.com/#/curso/dart)