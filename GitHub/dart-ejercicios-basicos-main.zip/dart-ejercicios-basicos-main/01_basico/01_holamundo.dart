
main() {

  print('Hola Mundo');


}

